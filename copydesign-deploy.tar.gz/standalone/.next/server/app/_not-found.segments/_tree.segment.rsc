:HL["/copydesign/_next/static/chunks/3b8uk9bnx-i8h.css","style"]
0:{"tree":{"name":"","param":null,"prefetchHints":16,"slots":{"children":{"name":"/_not-found","param":null,"prefetchHints":0,"slots":{"children":{"name":"__PAGE__","param":null,"prefetchHints":0,"slots":null}}}}},"staleTime":300,"buildId":"l3v0CuCi6hHGArgMoIBxi"}

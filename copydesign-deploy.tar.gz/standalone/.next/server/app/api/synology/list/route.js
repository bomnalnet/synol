var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/synology/list/route.js")
R.c("server/chunks/[root-of-the-server]__1f0yyn8._.js")
R.c("server/chunks/[root-of-the-server]__0xuaoik._.js")
R.c("server/chunks/_next-internal_server_app_api_synology_list_route_actions_0mxlcw8.js")
R.m(4944)
module.exports=R.m(4944).exports

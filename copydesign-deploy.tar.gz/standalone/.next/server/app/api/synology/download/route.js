var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/synology/download/route.js")
R.c("server/chunks/[root-of-the-server]__0_08qoq._.js")
R.c("server/chunks/[root-of-the-server]__0xuaoik._.js")
R.c("server/chunks/_next-internal_server_app_api_synology_download_route_actions_0vw_bzx.js")
R.m(5128)
module.exports=R.m(5128).exports

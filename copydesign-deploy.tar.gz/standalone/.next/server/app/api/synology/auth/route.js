var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/synology/auth/route.js")
R.c("server/chunks/[root-of-the-server]__0__iavb._.js")
R.c("server/chunks/[root-of-the-server]__0xuaoik._.js")
R.c("server/chunks/_next-internal_server_app_api_synology_auth_route_actions_0d4qm20.js")
R.m(42760)
module.exports=R.m(42760).exports

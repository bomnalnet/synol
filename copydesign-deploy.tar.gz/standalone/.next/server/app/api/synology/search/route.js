var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/synology/search/route.js")
R.c("server/chunks/[root-of-the-server]__0z8bz46._.js")
R.c("server/chunks/[root-of-the-server]__0xuaoik._.js")
R.c("server/chunks/_next-internal_server_app_api_synology_search_route_actions_1s8cfzn.js")
R.m(91166)
module.exports=R.m(91166).exports

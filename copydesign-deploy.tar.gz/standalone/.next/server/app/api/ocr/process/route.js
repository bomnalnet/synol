var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/ocr/process/route.js")
R.c("server/chunks/[root-of-the-server]__187j_y7._.js")
R.c("server/chunks/[root-of-the-server]__0xuaoik._.js")
R.c("server/chunks/node_modules_1zvcedj._.js")
R.c("server/chunks/_next-internal_server_app_api_ocr_process_route_actions_1g02egw.js")
R.m(31124)
module.exports=R.m(31124).exports

var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/ocr/sync/route.js")
R.c("server/chunks/[root-of-the-server]__09-iy1d._.js")
R.c("server/chunks/[root-of-the-server]__0xuaoik._.js")
R.c("server/chunks/_next-internal_server_app_api_ocr_sync_route_actions_1e9ke9b.js")
R.m(38424)
module.exports=R.m(38424).exports

var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/ocr/status/route.js")
R.c("server/chunks/[root-of-the-server]__0fom9t7._.js")
R.c("server/chunks/[root-of-the-server]__0xuaoik._.js")
R.c("server/chunks/_next-internal_server_app_api_ocr_status_route_actions_0jj12q5.js")
R.m(27564)
module.exports=R.m(27564).exports

var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/ocr/search/route.js")
R.c("server/chunks/[root-of-the-server]__02kraxa._.js")
R.c("server/chunks/[root-of-the-server]__0xuaoik._.js")
R.c("server/chunks/_next-internal_server_app_api_ocr_search_route_actions_0n1vsr7.js")
R.m(87707)
module.exports=R.m(87707).exports

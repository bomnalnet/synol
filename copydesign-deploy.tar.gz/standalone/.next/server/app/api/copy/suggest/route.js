var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/copy/suggest/route.js")
R.c("server/chunks/[root-of-the-server]__0u2lcmm._.js")
R.c("server/chunks/[root-of-the-server]__0xuaoik._.js")
R.c("server/chunks/node_modules_1zvcedj._.js")
R.c("server/chunks/_next-internal_server_app_api_copy_suggest_route_actions_1bt02rl.js")
R.m(40106)
module.exports=R.m(40106).exports

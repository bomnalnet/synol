var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/design/generate/route.js")
R.c("server/chunks/[root-of-the-server]__14972nb._.js")
R.c("server/chunks/[root-of-the-server]__0xuaoik._.js")
R.c("server/chunks/node_modules_1zvcedj._.js")
R.c("server/chunks/_next-internal_server_app_api_design_generate_route_actions_0p-muao.js")
R.m(73500)
module.exports=R.m(73500).exports

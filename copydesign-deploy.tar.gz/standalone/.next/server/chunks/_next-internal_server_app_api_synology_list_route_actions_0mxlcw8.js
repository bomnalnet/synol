module.exports=[28914,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_synology_list_route_actions_0mxlcw8.js.map
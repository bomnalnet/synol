module.exports=[95305,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_ocr_sync_route_actions_1e9ke9b.js.map
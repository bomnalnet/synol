module.exports=[10716,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_ocr_search_route_actions_0n1vsr7.js.map
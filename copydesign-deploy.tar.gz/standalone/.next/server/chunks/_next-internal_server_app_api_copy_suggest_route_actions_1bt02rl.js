module.exports=[36241,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_copy_suggest_route_actions_1bt02rl.js.map
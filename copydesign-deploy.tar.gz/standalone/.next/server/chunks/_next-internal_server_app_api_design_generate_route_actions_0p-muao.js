module.exports=[86618,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_design_generate_route_actions_0p-muao.js.map
module.exports=[22606,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_synology_search_route_actions_1s8cfzn.js.map
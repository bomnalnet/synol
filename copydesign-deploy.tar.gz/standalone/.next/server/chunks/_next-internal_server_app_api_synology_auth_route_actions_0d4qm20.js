module.exports=[79055,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_synology_auth_route_actions_0d4qm20.js.map
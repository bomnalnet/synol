module.exports=[68247,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_synology_download_route_actions_0vw_bzx.js.map
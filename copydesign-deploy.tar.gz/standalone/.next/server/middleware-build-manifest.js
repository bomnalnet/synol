globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/0cz1d0mv5g_q7.js"
  ],
  "lowPriorityFiles": [
    "static/l3v0CuCi6hHGArgMoIBxi/_buildManifest.js",
    "static/l3v0CuCi6hHGArgMoIBxi/_ssgManifest.js",
    "static/l3v0CuCi6hHGArgMoIBxi/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/1jq4o6yq14o4c.js",
    "static/chunks/38m3okrhn2l9-.js",
    "static/chunks/3n7dm2ojtyzwn.js",
    "static/chunks/turbopack-14xt8xgr6fif2.js"
  ]
};
